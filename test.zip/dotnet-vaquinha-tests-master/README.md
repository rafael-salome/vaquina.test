# dotnet-vaquinha-tests
Projeto Base para Testes - .Net Core  

## Digital Innovation One

[Clique aqui para se inscrever na Digital Innovation One](https://digitalinnovation.one/sign-up?ref=H395IYS4Z6)  

## Eliézer Zarpelão
[GitHub Timeline](https://elizarp.github.io/timeline/)  
[Linkedin](http://br.linkedin.com/in/eliezerzarpelao)  
[Github](https://github.com/elizarp) 

## Marcos Freire
[Linkedin](https://www.linkedin.com/in/marcos-freire-a73891125/)  
[Github](https://github.com/marcosfreire) 

## Slides
[Slides em PDF](TesteNetCore.pdf)