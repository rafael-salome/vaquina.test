﻿namespace Vaquinha.Domain.ViewModels
{
    public class EnderecoViewModel
    {
        public string CEP { get; set; }
        public string TextoEndereco { get; set; }
        public string Numero { get; set; }
        public string Complemento { get; set; }
        public string Cidade { get; set; }
        public string Estado { get; set; }
        public string Telefone { get; set; }
    }
}