﻿namespace Vaquinha.Domain.ViewModels
{
    public class CartaoCreditoViewModel
    {
        public string NomeTitular { get; set; }
        public string NumeroCartaoCredito { get; set; }
        public string Validade { get; set; }
        public string CVV { get; set; }
    }
}